<?php
require_once 'php/config/database.php';
$db = getDb();
$res = $db->fetchAll("DESCRIBE se_check_ins");
print_r($res);
?>
