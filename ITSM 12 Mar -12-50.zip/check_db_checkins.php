<?php
require_once 'php/config/database.php';
$db = getDb();
echo "Check-ins count: " . $db->count('se_check_ins') . "\n";
$rows = $db->fetchAll("SELECT * FROM se_check_ins ORDER BY created_at DESC LIMIT 5");
print_r($rows);
?>
