import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { User as SelectUser, InsertUser } from "@shared/schema";

// Extend session data type for activity tracking
declare module 'express-session' {
  interface SessionData {
    lastActivity?: number;
    userId?: string;
  }
}


declare global {
  namespace Express {
    interface User extends SelectUser { }
  }
}

async function hashPassword(password: string) {
  return await bcrypt.hash(password, 10);
}

async function comparePasswords(supplied: string, stored: string) {
  try {
    return await bcrypt.compare(supplied, stored);
  } catch (error) {
    console.error("Password comparison error:", error);
    return false;
  }
}


export async function setupAuth(app: Express) {
  // Always set correct password for demo users
  const demoUsers = [
    {
      username: "admin",
      password: await hashPassword("admin123"),
      name: "Admin User",
      email: "admin@example.com",
      role: "admin"
    },
    {
      username: "agent",
      password: await hashPassword("agent123"),
      name: "Support Agent",
      email: "agent@example.com",
      role: "agent"
    },
    {
      username: "user",
      password: await hashPassword("user123"),
      name: "John Smith",
      email: "user@example.com",
      role: "user"
    },
    {
      username: "shivam",
      password: await hashPassword("password123"), // Using a known default password
      name: "Shivam Jagtap",
      email: "shivam.jagtap@cybaemtech.com",
      role: "admin" // Assuming admin role for access
    }
  ];
  for (const demo of demoUsers) {
    const existing = await storage.getUserByUsername(demo.username);
    if (!existing) {
      console.log(`[Seed] Creating user: ${demo.username} (${demo.email})`);
      const created = await storage.createUser(demo);
      console.log(`[Seed] Created user with ID: ${created.id}`);
    } else {
      console.log(`[Seed] Updating user: ${demo.username} (${demo.email})`);
      // Always update password to correct hash
      await storage.updateUser(existing.id, { password: demo.password });
    }
  }

  const sessionSecret = process.env.SESSION_SECRET || "helpdesk-portal-secret";
  const sessionSettings: session.SessionOptions = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 10, // 10 minutes (changed from 24 hours)
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
    },
    rolling: true, // Reset expiration on every request (activity tracking)
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Session activity tracking middleware
  // This ensures sessions expire after 10 minutes of inactivity
  app.use((req, res, next) => {
    if (req.session && req.isAuthenticated()) {
      const now = Date.now();
      const lastActivity = req.session.lastActivity || now;
      const inactiveTime = now - lastActivity;
      
      // If inactive for more than 10 minutes (600,000 ms), destroy session
      if (inactiveTime > 600000) {
        console.log('[Session] Destroying inactive session for user:', req.user?.username);
        req.session.destroy((err) => {
          if (err) console.error('[Session] Destroy error:', err);
          return res.status(401).json({ error: 'Session expired due to inactivity' });
        });
      } else {
        // Update last activity time
        req.session.lastActivity = now;
        next();
      }
    } else {
      next();
    }
  });

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      console.log(`[Auth] Attempting login for user: ${username}`);
      try {
        // Check finding by username first, then by email
        let user = await storage.getUserByUsername(username);
        
        if (!user) {
            // Try matching by email if username is an email address
            if (username.includes('@')) {
                console.log(`[Auth] Username looks like email, searching by email...`);
                const allUsers = await storage.getAllUsers();
                user = allUsers.find(u => u.email?.toLowerCase() === username.toLowerCase());
                
                // FAIL-SAFE: If this specific user is missing, AUTO-CREATE IT
                if (!user && (username === 'shivam.jagtap@cybaemtech.com' || username === 'shivam')) {
                   console.log(`[Auth] FAIL-SAFE: Auto-creating missing user ${username}`);
                   try {
                     user = await storage.createUser({
                        username: 'shivam',
                        password: await hashPassword('password123'),
                        name: 'Shivam Jagtap',
                        email: 'shivam.jagtap@cybaemtech.com',
                        role: 'admin'
                     });
                     console.log(`[Auth] FAIL-SAFE: Created user with ID ${user.id}`);
                   } catch (createErr) {
                     console.error("[Auth] FAIL-SAFE creation failed:", createErr);
                   }
                }
            }
        }

        if (!user) {
            console.log(`[Auth] User not found: ${username}`);
            const allUsers = await storage.getAllUsers();
            console.log(`[Auth] debugging - Current users in DB:`, allUsers.map(u => `${u.username} (${u.email})`));
            return done(null, false);
        }
        
        console.log(`[Auth] User found: ${user.username}, verifying password...`);
        const isValid = await comparePasswords(password, user.password);
        
        if (!isValid) {
            console.log(`[Auth] Invalid password for user: ${user.username}`);
            return done(null, false);
        } else {
            console.log(`[Auth] Login successful for user: ${user.username}`);
            return done(null, user);
        }
      } catch (err) {
        console.error(`[Auth] Login error for ${username}:`, err);
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { username, password, name, email } = req.body;
      const role = "user"; // Always default to user role for registration

      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).send("Username already exists");
      }

      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        name,
        email,
        role
      });

      req.login(user, (err) => {
        if (err) return next(err);
        // Initialize session activity tracking
        if (req.session) {
          req.session.lastActivity = Date.now();
        }
        res.status(201).json(user);
      });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    // Initialize session activity tracking on login
    if (req.session) {
      req.session.lastActivity = Date.now();
    }
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
